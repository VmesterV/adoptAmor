<link rel="stylesheet" href="vistas/estilos/footer.css">
<footer id="contacto">
    <div class="container">
        <p>AdoptaAmor &copy; 2025 | Contacto: <a href="mailto:info@adoptaamor.org">info@adoptaamor.org</a></p>
    </div>
</footer>