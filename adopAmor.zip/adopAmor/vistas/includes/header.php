<link rel="stylesheet" href="vistas/estilos/header.css">
<header>
    <div class="container">
        <h1>adopt<span style="color: red;">Amor</span>🐾</h1>
        <nav>
            <ul>
                <li><a href="#" class="page-link" data-page="mascotas">Adopción</a></li>
                <li><a href="#" class="page-link" data-page="tienda">Tienda</a></li>
                <li><a href="#contacto" class="page-link">Contacto</a></li>
            </ul>
        </nav>
        <button id="darkModeToggle">🌙</button>
    </div>
</header>
<main class="container" id="main-content"></main>