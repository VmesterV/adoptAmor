<link rel="stylesheet" href="vistas/estilos/mascotas.css">
<section id="hero">
    <h2>Encuentra a tu amigo fiel</h2>
    <p>Explora nuestros perfiles y dale un hogar a una mascota necesitada.</p>
</section>

<section id="perros" class="pet-section">
    <h2>Perros en Adopción 🐶</h2>
    <div class="pet-grid" id="perros-grid"></div>
</section>

<section id="gatos" class="pet-section">
    <h2>Gatos en Adopción 🐱</h2>
    <div class="pet-grid" id="gatos-grid"></div>
</section>
