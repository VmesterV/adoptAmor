<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="vistas/js/agregar_mascotas/mascotas.js"></script>
<script src="vistas/js/agregar_mascotas/utiles.js"></script>
<script src="vistas/js/agregar_mascotas/navegacion.js"></script>
<script src="vistas/js/agregar_mascotas/main.js"></script>


<script src="vistas/js/tienda_objetos/productos.js"></script>
<script src="vistas/js/tienda_objetos/tienda_main.js"></script>
<script src="vistas/js/tienda_objetos/funciones.js"></script>
<script src="vistas/js/tienda_objetos/carrito.js"></script>