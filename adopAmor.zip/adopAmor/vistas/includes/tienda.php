<link rel="stylesheet" href="vistas/estilos/tienda.css">
<link rel="stylesheet" href="vistas/estilos/carrito.css">
<div id="tienda">
    <h2>🐶 Tienda de Accesorios para Mascotas 🐱</h2>

    <div id="lista-productos"></div>

    <hr>

    <div id="carrito">
      <h3>🛒 Carrito de Compras</h3>
      <ul id="lista-carrito"></ul>
      <p id="total">Total: S/ 0.00</p>
      <button id="vaciar-carrito">Vaciar Carrito</button>
    </div>
</div>