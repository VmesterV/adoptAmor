<?php
// crear_hash.php
$password_plano = '12345';
$hash = password_hash($password_plano, PASSWORD_DEFAULT);
echo $hash;
?>