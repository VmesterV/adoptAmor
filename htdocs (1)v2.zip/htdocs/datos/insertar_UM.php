<?php
    include("conexionbd.php");
    
    // La sentencia SQL es una única consulta INSERT con múltiples filas.
    $sql="
    insert into usuario (U_nombre, email, pass, rol, F_registro) 
    values 
    ('user', 'user@gmail.com', '12345', 'user','2025-10-20'),
    ('moder', 'moder@gmail.com', '12345', 'moder','2025-10-20');
    ";
    
    // Se usa mysqli_query() para una única sentencia SQL
    if (mysqli_query($con, $sql)) {
        echo "<br>usuario y moder insertados";
    } else {
        // En caso de error, muestra el mensaje de error de MySQL.
        die("Error al insertar datos: " . mysqli_error($con));
    }
    
    // Cierra la conexión
    mysqli_close($con);
?>