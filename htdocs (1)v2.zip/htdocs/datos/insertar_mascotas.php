<?php
    include("conexionbd.php");
    $sql="
    insert into mascota (nombre, edad, tipo, raza, ID_usuario)
    values
    ('roky','2','perro','Shiva','2'),
    ('Luna','3','perro','Golden','2'),
    ('Odin','5','perro','Dalmata','2'),
    ('Cosmo','7','perro','Pug','2'),
    ('Bruno','3','perro','Dorberman','2'),
    ('kira','2','perro','Maltes','2'),
    ('Simon','1','gato','Siames','2'),
    ('Simba','5','gato','Esfinge','2'),
    ('Sasha','3','gato','Angora','2'),
    ('Pelusa','5','gato','Persa','2'),
    ('Nala','6','gato','Vengala','2'),
    ('Chispa','4','gato','Bizco','2');

    ";
    if (mysqli_multi_query($con, $sql)) {
        //si mysqli_multi_query tiene éxito, iteramos sobre los resultados
        do {
            //para almacenar el primer resultados
            if ($result = mysqli_store_result($con)) {
                mysqli_free_result($result);
            }
        } while (mysqli_more_results($con) && mysqli_next_result($con));
    
        echo "<br>datos de las mascotas insertados insertados";
    } else {
        die("Error al insertar datos de las mascotas: " . mysqli_error($con));
    }
    mysqli_close($con);
?> 