-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-10-2025 a las 17:02:24
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_adoptamor`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adopcion`
--

CREATE TABLE `adopcion` (
  `ID_adopcion` int(11) NOT NULL,
  `F_adopcion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ID_mascota` int(11) NOT NULL,
  `ID_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallepedido`
--

CREATE TABLE `detallepedido` (
  `ID_detalle` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `ID_pedido` int(11) NOT NULL,
  `ID_producto` int(11) NOT NULL,
  `P_unitario_captura` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `ID_mascota` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `edad` int(11) NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `raza` varchar(30) NOT NULL,
  `ID_usuario` int(11) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`ID_mascota`, `nombre`, `edad`, `tipo`, `raza`, `ID_usuario`, `imagen`) VALUES
(1, 'roky', 2, 'perro', 'Shiva', 2, 'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
(2, 'Luna', 3, 'perro', 'Golden', 2, 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
(3, 'Odin', 5, 'perro', 'Dalmata', 2, 'https://www.purina.es/sites/default/files/styles/ttt_image_510/public/2024-02/sitesdefaultfilesstylessquare_medium_440x440public2022-09dalmatian.jpg?itok=GonE9SI9'),
(4, 'Cosmo', 7, 'perro', 'Pug', 2, 'https://blog.dogfydiet.com/wp-content/uploads/2024/02/Perro-pug-acostado-en-mueble.jpg'),
(5, 'Bruno', 3, 'perro', 'Dorberman', 2, 'https://cdn0.uncomo.com/es/posts/0/6/1/como_alimentar_a_un_doberman_cachorro_33160_600_square.jpg'),
(6, 'kira', 2, 'perro', 'Maltes', 2, 'https://estaticos-cdn.prensaiberica.es/clip/823f515c-8143-4044-8f13-85ea1ef58f3a_16-9-discover-aspect-ratio_default_0.jpg'),
(7, 'Simon', 1, 'gato', 'Siames', 2, 'https://images.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'),
(8, 'Simba', 5, 'gato', 'Esfinge', 2, 'https://i.pinimg.com/736x/ef/8c/dc/ef8cdc3899137eb61f03547419b0518d.jpg'),
(9, 'Sasha', 3, 'gato', 'Angora', 2, 'https://i.pinimg.com/originals/8e/d7/41/8ed7410285f101ba5892ff723c91fa75.jpg'),
(10, 'Pelusa', 5, 'gato', 'Persa', 2, 'https://www.zooplus.es/magazine/wp-content/uploads/2017/10/fotolia_103481419.webp'),
(11, 'Nala', 6, 'gato', 'Vengala', 2, 'https://www.purina.es/sites/default/files/styles/ttt_image_510/public/2021-01/Bengal.1.jpg?itok=98LQ1RfI'),
(12, 'Chispa', 4, 'gato', 'Bizco', 2, 'https://st.depositphotos.com/2836705/3618/i/450/depositphotos_36180101-stock-photo-cross-eyed-cat.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `ID_pedido` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `D_envio` varchar(255) DEFAULT NULL,
  `ID_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `ID_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `esta_activo` tinyint(1) NOT NULL DEFAULT 1,
  `ID_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID_producto`, `nombre`, `descripcion`, `precio`, `imagen`, `stock`, `esta_activo`, `ID_usuario`) VALUES
(1, 'juguete para perros', 'pelota resistente', 25.00, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR08k71IxKbQlyNvTwuYxgGK7KCDcCVZ5rg7g&s', 10, 1, 2),
(2, 'collar ajustable', 'Collar de nylon', 15.50, 'https://cdnx.jumpseller.com/ace-comaderas/image/35787577/resize/1200/1200?1693843433', 10, 1, 2),
(3, 'cama para mascotas', 'Cama acolchada de algondon suave', 80.00, 'https://rapipet.pe/wp-content/uploads/2022/01/Diseno-sin-titulo-3-3.png', 10, 1, 2),
(4, 'Comedero doble', 'Compartimento para agua y comida', 35.90, 'https://img.ltwebstatic.com/images3_spmp/2024/04/25/39/1714006615c136be308d7db1fdc342a17c695da3f5.webp', 10, 1, 2),
(5, 'Rascador para gato', 'Rascador de sisal', 60.00, 'https://png.pngtree.com/png-vector/20240706/ourmid/pngtree-accessories-for-cats-cat-scratching-post-png-image_13011231.png', 10, 1, 2),
(6, 'Arnes reflectante', 'Seguridad nocturna', 45.00, 'https://papopet.pe/wp-content/uploads/2024/08/416.webp', 10, 1, 2),
(7, 'Shampoo para perros', 'Cuida el pelaje', 22.00, 'https://petstorelima.pe/wp-content/uploads/2023/01/shampoo-frescan-piel-sensible-.png', 10, 1, 2),
(8, 'Trasnportadora', 'Caja transportadora ventilada', 110.00, 'https://pintospetshop.com/wp-content/uploads/2023/11/Savic-Transportador-Plomo-para-Mascotas-Trotter-1-640x640.png', 10, 1, 2),
(9, 'Ropa de gato', 'Ropa para tu michi', 50.00, 'https://magavet.co/wp-content/uploads/2021/01/RPC-Gato-DuoDry-Rosa.png', 10, 1, 2),
(10, 'Ropa de perro', 'Lo mejor de lo mejor', 60.00, 'https://www.macropaparamascotas.com/wp-content/uploads/2025/05/ropa-perro-camisetas.webp', 10, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID_usuario` int(11) NOT NULL,
  `U_nombre` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `rol` varchar(30) NOT NULL,
  `F_registro` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_usuario`, `U_nombre`, `email`, `pass`, `rol`, `F_registro`) VALUES
(1, 'user', 'user@gmail.com', '$2y$10$PDqurm4yZUDAwEQ2fccSAOCJ7UbVr1nsVS.c4HwpzTT3z5hIqq5ke', 'user', '2025-10-20'),
(2, 'moder', 'moder@gmail.com', '$2y$10$PDqurm4yZUDAwEQ2fccSAOCJ7UbVr1nsVS.c4HwpzTT3z5hIqq5ke', 'moder', '2025-10-20');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `adopcion`
--
ALTER TABLE `adopcion`
  ADD PRIMARY KEY (`ID_adopcion`),
  ADD KEY `ID_usuario` (`ID_usuario`),
  ADD KEY `ID_mascota` (`ID_mascota`);

--
-- Indices de la tabla `detallepedido`
--
ALTER TABLE `detallepedido`
  ADD PRIMARY KEY (`ID_detalle`),
  ADD UNIQUE KEY `uk_pedido_producto` (`ID_pedido`,`ID_producto`),
  ADD KEY `ID_producto` (`ID_producto`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`ID_mascota`),
  ADD KEY `ID_usuario` (`ID_usuario`);

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`ID_pedido`),
  ADD KEY `ID_usuario` (`ID_usuario`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ID_producto`),
  ADD KEY `ID_usuario` (`ID_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `adopcion`
--
ALTER TABLE `adopcion`
  MODIFY `ID_adopcion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detallepedido`
--
ALTER TABLE `detallepedido`
  MODIFY `ID_detalle` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mascota`
--
ALTER TABLE `mascota`
  MODIFY `ID_mascota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `pedido`
--
ALTER TABLE `pedido`
  MODIFY `ID_pedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `ID_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `adopcion`
--
ALTER TABLE `adopcion`
  ADD CONSTRAINT `adopcion_ibfk_1` FOREIGN KEY (`ID_usuario`) REFERENCES `usuario` (`ID_usuario`),
  ADD CONSTRAINT `adopcion_ibfk_2` FOREIGN KEY (`ID_mascota`) REFERENCES `mascota` (`ID_mascota`);

--
-- Filtros para la tabla `detallepedido`
--
ALTER TABLE `detallepedido`
  ADD CONSTRAINT `detallepedido_ibfk_1` FOREIGN KEY (`ID_pedido`) REFERENCES `pedido` (`ID_pedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `detallepedido_ibfk_2` FOREIGN KEY (`ID_producto`) REFERENCES `producto` (`ID_producto`);

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `mascota_ibfk_1` FOREIGN KEY (`ID_usuario`) REFERENCES `usuario` (`ID_usuario`);

--
-- Filtros para la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`ID_usuario`) REFERENCES `usuario` (`ID_usuario`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`ID_usuario`) REFERENCES `usuario` (`ID_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
