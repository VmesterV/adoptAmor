
<!DOCTYPE html>
<html lang="es">
<?php
include("vistas/includes/head.php");
?>
<body>
<?php
include("vistas/includes/header.php");
include("vistas/includes/form.php");
include("vistas/includes/footer.php");
include("vistas/includes/script.php");
?>
</body>
</html>