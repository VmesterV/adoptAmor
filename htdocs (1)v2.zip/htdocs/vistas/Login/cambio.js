// login.js - (Script para la página principal)
document.addEventListener('DOMContentLoaded', (event) => {
    // Busca el botón 'login' en la página principal
    const boton = document.getElementById('login');

    // Si lo encuentra, le asigna el evento
    if (boton) {
        boton.addEventListener('click', function() {
            // Redirige a la página de login
            window.location.href = 'vistas/Login/lateral.php';
        });
    }
});