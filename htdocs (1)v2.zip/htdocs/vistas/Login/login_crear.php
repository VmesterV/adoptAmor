<div class="seccion-registro">

    <div class="tarjeta">
        
        <div class="icono-huella">
            <i class="fas fa-paw" aria-hidden="true"></i>
        </div>
        
        <h2 class="titulo-registro">Crear Cuenta</h2>
        
        <form class="formulario">
            
            <div class="campo-formulario">
                <label for="nombre">Nombre completo</label>
                <input type="text" id="nombre" placeholder="Ingresa tu nombre completo" required>
                <i class="icono-campo fas fa-user"></i>
            </div>
            
            <div class="campo-formulario">
                <label for="email">Correo electrónico</label>
                <input type="email" id="email" placeholder="tu@email.com" required>
                <i class="icono-campo fas fa-envelope"></i>
            </div>
            
            <div class="campo-formulario">
                <label for="password">Contraseña</label>
                <input type="password" id="password" placeholder="••••••••" required>
                <i class="icono-campo fas fa-lock"></i>
            </div>
            
            <div class="campo-formulario">
                <label for="confirmar-password">Confirmar contraseña</label>
                <input type="password" id="confirmar-password" placeholder="••••••••" required>
                <i class="icono-campo fas fa-lock"></i>
            </div>
            
            <button type="submit" class="boton-principal">Crear cuenta</button>
            
            <div class="enlace-login">
                <p>¿Ya tienes cuenta? 
                    <button type="button" class="nav-link" data-vista="login_iniciar.php">
                        Inicia sesión
                    </button>
                </p>
            </div>
        </form>
    </div>
</div>