<div class="seccion-login">
    <div class="tarjeta">
        
        <div class="icono-huella">
            <i class="fas fa-paw" aria-hidden="true"></i>
        </div>
        
        <h2 class="titulo-login">Inicia Sesión</h2>
        
        <form class="formulario" id="form-login">
            
            <div id="login-error-msg" style="color: red; text-align: center; margin-bottom: 10px;"></div>

            <div class="campo-formulario">
                <label for="email">Email</label>
                <input type="email" id="email" placeholder="tu@email.com" required>
                <i class="icono-campo fas fa-envelope"></i>
            </div>
            
            <div class="campo-formulario">
                <label for="password">Contraseña</label>
                <input type="password" id="password" placeholder="••••••••" required>
                <i class="icono-campo fas fa-lock"></i>
            </div>
            
            <div class="opciones-adicionales">
                <button type="button" class="nav-link" data-vista="login_recuperar.php">Olvide mi contraseña</button>
            </div>
            
            <button type="submit" class="boton-principal">Entrar</button>
            
            <div class="enlace-registro">
                <p>¿No tienes cuenta? <button type="button" class="nav-link" data-vista="login_crear.php">Regístrate aquí</button></p>
            </div>
        </form>
    </div>
</div>