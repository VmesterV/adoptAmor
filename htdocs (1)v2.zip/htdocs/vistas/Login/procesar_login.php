<?php
session_start();

// Si se llama con ?logout=1, cerrar sesión
if (isset($_GET['logout']) && $_GET['logout'] == 1) {
    session_destroy();
    header('Location: ../../index.php');
    exit();
}
?>




<?php
// procesar_login.php (Versión Limpia y Segura)

session_start();

// Configuración de tu Base de Datos
$db_host = 'localhost';
$db_name = 'db_adoptamor';
$db_user = 'adoptAmor';
$db_pass = ''; 

// Obtener los datos JSON
$datos = json_decode(file_get_contents("php://input"));

if (!isset($datos->email) || !isset($datos->password)) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
    exit;
}

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Buscamos al usuario SOLO por el email
    $stmt = $pdo->prepare("SELECT * FROM usuario WHERE email = ?");
    $stmt->execute([$datos->email]);
    
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. Verificamos el usuario y la contraseña
    if ($usuario && password_verify($datos->password, $usuario['pass'])) {
        
        // ¡ÉXITO!
        $_SESSION['usuario_id'] = $usuario['ID_usuario'];
        $_SESSION['usuario_nombre'] = $usuario['U_nombre'];
        $_SESSION['usuario_rol'] = $usuario['rol'];
        
        echo json_encode([
            'success' => true,
            'redirect' => '../../index.php' // Redirige al index principal
        ]);
        
    } else {
        // Error: Email o contraseña incorrectos
        echo json_encode([
            'success' => false,
            'message' => 'Email o contraseña incorrectos.'
        ]);
    }

} catch (PDOException $e) {
    // Error genérico de BD
    echo json_encode([
        'success' => false,
        'message' => 'Error al conectar con el servidor.'
    ]);
}