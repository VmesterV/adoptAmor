// vistas_login.js

document.addEventListener('DOMContentLoaded', (event) => {
    
    // 1. Obtener el contenedor principal
    const mainContent = document.getElementById('main-content');
    
    // Si 'main-content' no existe, no hagas nada.
    if (!mainContent) {
        console.error("Error: No se encontró el elemento #main-content.");
        return;
    }

    // --- FUNCIÓN PARA CARGAR VISTAS (ej. login_crear.php) ---
    async function cargarVista(url) {
        try {
            mainContent.innerHTML = '<h2>Cargando...</h2>';
            const response = await fetch(url);
            if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
            const html = await response.text();
            mainContent.innerHTML = html;
        } catch (error) {
            mainContent.innerHTML = `<p style="color:red;">Error al cargar la vista.</p>`;
        }
    }

    // --- ESCUCHADOR PARA NAVEGACIÓN (Botones .nav-link) ---
    mainContent.addEventListener('click', (event) => {
        const link = event.target.closest('.nav-link');
        if (link) {
            event.preventDefault();
            const vistaUrl = link.getAttribute('data-vista');
            if (vistaUrl) {
                cargarVista(vistaUrl);
            }
        }
    });

    // --- ¡AQUÍ ESTÁ LA LLAMADA A 'procesar_login.php'! ---
    // Escuchador para el envío del formulario
    mainContent.addEventListener('submit', async (event) => {
        
        // 2. Comprobar si el evento viene del formulario correcto
        if (event.target.id === 'form-login') {
            
            // 3. Prevenir que la página se recargue
            event.preventDefault(); 
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorMsg = document.getElementById('login-error-msg');

            try {
                // 4. ¡LA LLAMADA FETCH QUE FALTABA!
                const response = await fetch('procesar_login.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: email, password: password })
                });

                const data = await response.json();

                if (data.success) {
                    // Éxito: Redirigir al index principal
                    window.location.href = data.redirect; // (../../index.php)
                } else {
                    // Error: Mostrar mensaje de PHP (ej. 'DEBUG: ...')
                    if (errorMsg) errorMsg.textContent = data.message;
                }
            } catch (error) {
                if (errorMsg) errorMsg.textContent = 'Error de red. Inténtalo de nuevo.';
            }
        }
    });

    // --- Cargar la vista por defecto al iniciar ---
    // (Esta es la línea que antes estaba en la línea 18)
    cargarVista('login_iniciar.php');
});