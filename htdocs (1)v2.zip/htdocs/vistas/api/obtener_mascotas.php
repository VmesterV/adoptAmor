<?php
// vistas/api/obtener_mascotas.php

// Devuelve los datos como JSON
header('Content-Type: application/json');

// 1. Configuración de la Base de Datos (la misma de tu login)
$db_host = 'localhost';
$db_name = 'db_adoptamor';
$db_user = 'adoptAmor';
$db_pass = ''; 

// 2. Obtener el tipo de mascota de la URL (ej: ...?tipo=perro)
$tipo_mascota = isset($_GET['tipo']) ? $_GET['tipo'] : '';

if (empty($tipo_mascota) || ($tipo_mascota !== 'perro' && $tipo_mascota !== 'gato')) {
    echo json_encode(['success' => false, 'message' => 'Tipo no válido.']);
    exit;
}

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 3. Preparar la consulta (ADAPTADA A TU TABLA 'mascota')
    // - Usamos 'ID_mascota' y le ponemos el alias 'id' (que utiles.js espera)
    // - Usamos CONCAT() para añadir " años" a la edad (que utiles.js espera)
    $stmt = $pdo->prepare("
        SELECT 
            ID_mascota AS id, 
            nombre, 
            raza, 
            CONCAT(edad, ' años') AS edad, 
            imagen 
        FROM mascota 
        WHERE tipo = ?
    ");
    
    $stmt->execute([$tipo_mascota]);
    
    $mascotas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Devolver los datos
    echo json_encode($mascotas);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión: ' . $e->getMessage()
    ]);
}
?>
