<?php
// vistas/api/obtener_productos.php

header('Content-Type: application/json');

// 1. Configuración de la Base de Datos
$db_host = 'localhost';
$db_name = 'db_adoptamor';
$db_user = 'adoptAmor';
$db_pass = ''; 

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2. Preparar la consulta
    // ¡CAMBIOS AQUÍ!
    // - Se usa la tabla "producto" (en singular)
    // - Se filtran solo los productos donde "esta_activo" es 1 (TRUE)
    $stmt = $pdo->prepare("
        SELECT 
            ID_producto AS id, 
            nombre, 
            descripcion, 
            precio, 
            imagen,
            stock
        FROM producto
        WHERE esta_activo = 1
    ");
    
    $stmt->execute();
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Devolver los datos como JSON
    echo json_encode($productos);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión: ' . $e->getMessage()
    ]);
}
?>

