<link rel="stylesheet" href="vistas/estilos/header.css">
<link rel="stylesheet" href="vistas/estilos/base_layout.css">
<header>
    <div class="container">
        <h1>adopt<span style="color: red;">Amor</span>🐾</h1>
        <nav>
            <ul>
                <li><a href="#" class="page-link" data-page="mascotas">Adopción</a></li>
                <li><a href="#" class="page-link" data-page="tienda">Tienda</a></li>
                <li><a href="#contacto" class="page-link">Contacto</a></li>
            </ul>
        </nav>
        
        <!-- =================================== -->
        <!-- =      INICIO CARRITO GLOBO       = -->
        <!-- =================================== -->
        
        <!-- 1. El "Globo" del Carrito (Siempre visible) -->
        <button id="carrito-globo-btn" class="carrito-globo">
            🛒
            <!-- El contador de productos -->
            <span id="carrito-contador" class="carrito-contador">0</span>
        </button>

        <!-- =================================== -->
        <!-- =        FIN CARRITO GLOBO        = -->
        <!-- =================================== -->

        <button id="darkModeToggle">🌙</button>
        
<?php
// Arranque de sesión solo si aún no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Si NO hay usuario logueado: mostramos el botón
if (!isset($_SESSION['usuario_id'])): ?>
    <button id="login">Iniciar sesión</button>
<?php else: ?>
    <!-- Si está logueado: mostrar bienvenida y botón cerrar sesión -->
    <span class="bienvenida">Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?>!</span>
    <a href="vistas/Login/procesar_login.php?logout=1" id="logout" class="btn btn-danger">Cerrar sesión</a>
<?php endif; ?>






    </div>
</header>
<main class="main-container" id="main-content"></main>

<!-- =================================== -->
<!-- =     INICIO CARRITO MODAL      = -->
<!-- =================================== -->

<!-- 2. El Overlay (para cerrar el modal al hacer clic fuera) -->
<div id="carrito-overlay" class="carrito-overlay"></div>

<!-- 3. El Modal del Carrito (Oculto por defecto) -->
<aside id="carrito-modal" class="carrito-modal">
    <div class="carrito-modal-header">
        <h3>Mi Carrito</h3>
        <button id="carrito-cerrar-btn" class="carrito-cerrar-btn">&times;</button>
    </div>
    
    <ul id="lista-carrito" class="carrito-modal-lista">
        <!-- 'funciones.js' llenará esto -->
        <li>No hay productos en el carrito.</li>
    </ul>
    
    <div class="carrito-modal-footer">
        <p id="total" class="total-carrito">Total: S/ 0.00</p>
        <button id="vaciar-carrito" class="item-card-button" style="background-color: #c0392b;">Vaciar Carrito</button>
        <button class="item-card-button" style="margin-top: 10px;">Finalizar Compra</button>
    </div>
</aside>

<!-- =================================== -->
<!-- =      FIN CARRITO MODAL       = -->
<!-- =================================== -->

