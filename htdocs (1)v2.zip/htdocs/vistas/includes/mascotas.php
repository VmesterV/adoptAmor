<!--
  Este archivo es cargado por AJAX.
  Define la estructura de la página de mascotas.
-->

<!-- Sección Hero -->
<section id="hero">
  <h2>Encuentra a tu Amigo Fiel</h2>
  <p>Explora cientos de perfiles de mascotas adorables que esperan un hogar.</p>
</section>

<!-- Sección Perros -->
<section class="pet-section">
  <h2>Perros en Adopción 🐶</h2>
  <!-- 
    ¡CAMBIO AQUÍ! 
    Cambiamos la clase a "grid-mascotas" (3 por fila).
  -->
  <div id="perros-grid" class="grid-mascotas">
    <!-- El script 'app_mascotas.js' llenará esto -->
  </div>
</section>

<!-- Sección Gatos -->
<section class="pet-section">
  <h2>Gatos en Adopción 🐱</h2>
  <!-- 
    ¡CAMBIO AQUÍ! 
    Cambiamos la clase a "grid-mascotas" (3 por fila).
  -->
  <div id="gatos-grid" class="grid-mascotas">
    <!-- El script 'app_mascotas.js' llenará esto -->
  </div>
</section>

