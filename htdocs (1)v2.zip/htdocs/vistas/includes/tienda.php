<!--
  Este archivo es cargado por AJAX.
  Define la estructura de la página de la tienda.
-->

<div id="tienda">
  
  <div class="tienda-header">
    <h2>Tienda de Accesorios 🛍️</h2>
  </div>

  <!-- 
    La clase "grid-productos" (5 por fila) que definimos antes
  -->
  <div id="lista-productos" class="grid-productos">
    <!-- El script 'tienda_main.js' llenará esto -->
  </div>

  <!-- 
    ¡ELIMINADO!
    La '<aside class="carrito-sidebar">' ya no va aquí.
    Ahora está de forma global en header.php
  -->

</div>

