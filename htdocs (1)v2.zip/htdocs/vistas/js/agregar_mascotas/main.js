// main.js
document.addEventListener("DOMContentLoaded", () => {
    const mainContent = document.getElementById('main-content');
    const navLinks = document.querySelectorAll('.page-link');
    const darkModeToggle = document.getElementById("darkModeToggle");
    const adopcionModalElement = document.getElementById('adopcionModal');
    
    // Asumiendo que Bootstrap está cargado y 'adopcionModalElement' existe
    if (!adopcionModalElement) {
        console.error("Error: El elemento del modal #adopcionModal no se encontró.");
        return;
    }
    const adopcionModal = new bootstrap.Modal(adopcionModalElement);
    let count = 0;

    // --- ¡FUNCIÓN MODIFICADA! ---
    // Ahora es 'async' y usa 'fetch' para obtener datos de la BD
    async function initializePetGrids() {
        const perrosGrid = document.getElementById('perros-grid');
        const gatosGrid = document.getElementById('gatos-grid');

        if (!perrosGrid || !gatosGrid) {
             console.warn("Grids de perros o gatos no encontrados en esta vista.");
             return;
        }

        // Mostrar estado de carga
        perrosGrid.innerHTML = '<p>Cargando perros...</p>';
        gatosGrid.innerHTML = '<p>Cargando gatos...</p>';

        try {
            // 1. Definir las rutas a la API que creamos
            // (La ruta sube 2 niveles desde 'vistas/js/agregar_mascotas/' a 'vistas/' y luego entra a 'api/')
            const urlPerros = 'vistas/api/obtener_mascotas.php?tipo=perro';
            const urlGatos = 'vistas/api/obtener_mascotas.php?tipo=gato';

            // 2. Hacer ambas peticiones a la vez (más rápido)
            const [perrosResponse, gatosResponse] = await Promise.all([
                fetch(urlPerros),
                fetch(urlGatos)
            ]);

            if (!perrosResponse.ok || !gatosResponse.ok) {
                throw new Error("Error en la red al cargar mascotas");
            }

            const perros = await perrosResponse.json();
            const gatos = await gatosResponse.json();

            // 3. Limpiar y poblar la grid de Perros
            perrosGrid.innerHTML = '';
            if (perros.length > 0) {
                // ¡Usa la función de utiles.js!
                perros.forEach(pet => perrosGrid.appendChild(createPetCard(pet)));
            } else {
                perrosGrid.innerHTML = '<p>No hay perros disponibles por ahora.</p>';
            }

            // 4. Limpiar y poblar la grid de Gatos
            gatosGrid.innerHTML = '';
            if (gatos.length > 0) {
                // ¡Usa la función de utiles.js!
                gatos.forEach(pet => gatosGrid.appendChild(createPetCard(pet)));
            } else {
                gatosGrid.innerHTML = '<p>No hay gatos disponibles por ahora.</p>';
            }

            // 5. Asignar eventos a los nuevos botones
            // ¡Usa la función de utiles.js!
            attachAdoptButtonEvents(adopcionModal, count);

        } catch (error) {
            console.error("Error al inicializar las mascotas:", error);
            perrosGrid.innerHTML = '<p>Error al cargar mascotas. Inténtalo más tarde.</p>';
            gatosGrid.innerHTML = '<p>Error al cargar mascotas. Inténtalo más tarde.</p>';
        }
    }
    // --- FIN DE LA FUNCIÓN MODIFICADA ---

    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });

    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            const page = link.dataset.page;
            if (page) {
                event.preventDefault();
                // ¡Usa la función de navegacion.js!
                loadContent(page, mainContent, initializePetGrids);
            }
        });
    });

    // Carga inicial (esto no cambia, sigue funcionando igual)
    loadContent('mascotas', mainContent, initializePetGrids);

    const carritoGloboBtn = document.getElementById('carrito-globo-btn');
    const carritoModal = document.getElementById('carrito-modal');
    const carritoOverlay = document.getElementById('carrito-overlay');
    const carritoCerrarBtn = document.getElementById('carrito-cerrar-btn');

    function abrirCarrito() {
        carritoModal.classList.add('abierto');
        carritoOverlay.classList.add('abierto');
    }

    function cerrarCarrito() {
        carritoModal.classList.remove('abierto');
        carritoOverlay.classList.remove('abierto');
    }

    // Abrir modal
    if (carritoGloboBtn) {
        carritoGloboBtn.addEventListener('click', abrirCarrito);
    }
    
    // Cerrar modal
    if (carritoCerrarBtn) {
        carritoCerrarBtn.addEventListener('click', cerrarCarrito);
    }
    if (carritoOverlay) {
        carritoOverlay.addEventListener('click', cerrarCarrito);
    }

});
