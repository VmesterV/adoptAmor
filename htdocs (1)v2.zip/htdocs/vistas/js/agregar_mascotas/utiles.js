// utiles.js
// --- FUNCIONES DE UTILIDAD ---

/**
 * Crea el HTML para una tarjeta de mascota usando las clases base.
 */
function createPetCard(pet) {
    const card = document.createElement('div');
    // Usamos la clase base
    card.classList.add('item-card'); 

    const edadStr = /años/i.test(pet.edad) ? pet.edad : `${pet.edad} años`;

    // Usamos la estructura HTML genérica
    card.innerHTML = `
      <div class="item-card-image-container">
        <img src="${pet.imagen}" alt="${pet.nombre}" onerror="this.src='https://placehold.co/400x400/EFEFEF/AAAAAA?text=Sin+Imagen'">
      </div>
      <div class="item-card-info">
        <h3>${pet.nombre}</h3>
        <p class="info-grow"><strong>Raza:</strong> ${pet.raza} | <strong>Edad:</strong> ${edadStr}</p>
        <button class="item-card-button adopt-btn" data-pet-id="${pet.id}" data-pet-name="${pet.nombre}">
          Adoptar
        </button>
      </div>
    `;
    // Nota: Mantenemos 'adopt-btn' para que el selector de eventos siga funcionando
    return card;
}

/**
 * Asigna los eventos de clic a los botones "Adoptar".
 */
function attachAdoptButtonEvents(adopcionModal, count) {
    // El selector .adopt-btn sigue funcionando
    const adoptButtons = document.querySelectorAll(".adopt-btn"); 
    const modalTitle = document.getElementById("modal-pet-name");
    const inputMascota = document.getElementById("mascotaSeleccionada");

    if (!adopcionModal || !modalTitle || !inputMascota) {
      console.warn("Elementos del modal no encontrados. El botón 'Adoptar' no funcionará.");
      return;
    }

    adoptButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const petId = btn.dataset.petId;
            const petName = btn.dataset.petName;
            
            modalTitle.textContent = petName;
            inputMascota.value = petId;
            
            if (typeof adopcionModal.show === 'function') {
              adopcionModal.show();
            } else if (typeof adopcionModal.show === 'object') {
              adopcionModal.show(); 
            }
            
            count++;
        });
    });
}

