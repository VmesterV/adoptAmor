// --- funciones.js ---

let carrito = [];
let productos = []; // Variable global para productos

/**
 * Renderiza todos los productos en la lista de productos.
 */
function renderProductos() {
  // 'listaProductos' se define en 'tienda_main.js'
  if (!listaProductos) return; 
  
  listaProductos.innerHTML = "";
  productos.forEach(prod => {
    const div = document.createElement("div");
    // Usamos las clases unificadas de 'base-card-styles.css'
    div.classList.add("item-card"); 
    
    const precioNum = parseFloat(prod.precio);
    const stock = parseInt(prod.stock);

    div.innerHTML = `
      <div class="item-card-image-container">
        <img src="${prod.imagen}" alt="${prod.nombre}" onerror="this.src='https://placehold.co/300x300/EFEFEF/AAAAAA?text=Sin+Imagen'">
      </div>
      <div class="item-card-info">
        <h3>${prod.nombre}</h3>
        <p class="info-grow">${prod.descripcion}</p>
        <p class="item-card-price">S/ ${precioNum.toFixed(2)}</p>
        <p class="item-card-stock">Stock: ${stock}</p>
        <button class="item-card-button" ${stock <= 0 ? "disabled" : ""}>
          ${stock > 0 ? "Agregar al carrito 🛍️" : "Sin stock"}
        </button>
      </div>
    `;
    const boton = div.querySelector("button");
    boton.addEventListener("click", () => agregarAlCarrito(prod.id));
    listaProductos.appendChild(div);
  });
}

/**
 * Agrega un producto al carrito y actualiza la UI.
 * @param {number} id - El ID del producto a agregar.
 */
function agregarAlCarrito(id) {
  const producto = productos.find(p => p.id === id);
  if (producto && producto.stock > 0) {
    producto.stock -= 1; // Disminuye el stock en la lista principal
    
    // ¡NUEVA LÓGICA DE CANTIDAD!
    const itemEnCarrito = carrito.find(p => p.id === id);
    if (itemEnCarrito) {
      itemEnCarrito.cantidad += 1; // Si ya está, suma 1
    } else {
      // Si es nuevo, lo añade con cantidad 1
      carrito.push({ ...producto, cantidad: 1 }); 
    }
    
    renderProductos(); // Actualiza la lista de productos (para mostrar el stock reducido)
    renderCarrito();   // Actualiza el carrito
  }
}

/**
 * Renderiza los items del carrito y el total.
 */
function renderCarrito() {
  // Estos elementos AHORA SON GLOBALES (en header.php)
  const listaCarritoGlobal = document.getElementById('lista-carrito');
  const totalGlobal = document.getElementById('total');
  const contadorGlobo = document.getElementById('carrito-contador');

  if (!listaCarritoGlobal || !totalGlobal || !contadorGlobo) return;

  listaCarritoGlobal.innerHTML = ""; // Limpia la lista del modal
  
  if (carrito.length === 0) {
      listaCarritoGlobal.innerHTML = "<li>No hay productos en el carrito.</li>";
  } else {
      carrito.forEach(item => {
          const li = document.createElement("li");
          const precioNum = parseFloat(item.precio);
          li.innerHTML = `
              <span>${item.nombre}</span>
              <span>
                  <span class="cantidad-item">x${item.cantidad}</span> 
                  S/ ${(precioNum * item.cantidad).toFixed(2)}
              </span>
          `;
          listaCarritoGlobal.appendChild(li);
      });
  }
  
  // Calcula el total
  const totalCompra = carrito.reduce((acc, item) => acc + (parseFloat(item.precio) * item.cantidad), 0);
  totalGlobal.textContent = `Total: S/ ${totalCompra.toFixed(2)}`;

  // ¡NUEVO! Actualiza el contador del globo
  const totalItems = carrito.reduce((acc, item) => acc + item.cantidad, 0);
  contadorGlobo.textContent = totalItems;
  
  if (totalItems > 0) {
      contadorGlobo.classList.add('visible');
  } else {
      contadorGlobo.classList.remove('visible');
  }
}

