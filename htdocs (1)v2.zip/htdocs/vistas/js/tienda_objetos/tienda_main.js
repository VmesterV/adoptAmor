// Variables globales para la tienda
// 'productos' y 'carrito' están en 'funciones.js'
let listaProductos, listaCarrito, total, btnVaciar;


async function initializeTienda() {
  // 1. Inicializar los elementos del DOM
  // Estos elementos ahora son GLOBALES, pero la función los busca
  listaProductos = document.getElementById("lista-productos");
  listaCarrito = document.getElementById("lista-carrito");
  total = document.getElementById("total");
  btnVaciar = document.getElementById("vaciar-carrito");

  // Si no estamos en la página de la tienda, 'lista-productos' no existirá.
  if (!listaProductos) {
    console.warn("Elemento #lista-productos no encontrado. (No es la página de tienda)");
    return;
  }
  
  // Si los elementos globales del carrito no están (error grave), salir.
  if (!listaCarrito || !total || !btnVaciar) {
    console.error("Elementos vitales del carrito no encontrados en header.php");
    return;
  }

  // 2. Mostrar estado de carga
  listaProductos.innerHTML = '<p>Cargando productos...</p>';

  try {
    // 3. Obtener productos de la base de datos
    // (Ajusta la ruta si 'tienda_main.js' no está en la misma carpeta que 'main.js')
    const response = await fetch('vistas/api/obtener_productos.php');
    if (!response.ok) {
        throw new Error("Error en la red al cargar productos");
    }
    
    // 4. Asignamos los productos de la BD a la variable global 'productos'
    productos = await response.json();

    // 5. Renderizamos productos y el estado inicial del carrito
    renderProductos();
    renderCarrito(); // Asegura que el carrito se muestre correctamente al cargar la pág.

  } catch (error) {
    console.error("Error al inicializar la tienda:", error);
    listaProductos.innerHTML = '<p>Error al cargar productos. Inténtalo más tarde.</p>';
  }

  // 6. Lógica de "Vaciar Carrito"
  // (Esta lógica ahora usa la variable 'productos' global)
  btnVaciar.addEventListener("click", () => {
    // Devuelve el stock a la lista principal de 'productos'
    carrito.forEach(itemCarrito => {
      const productoOriginal = productos.find(p => p.id === itemCarrito.id);
      if (productoOriginal) {
        productoOriginal.stock += itemCarrito.cantidad;
      }
    });
    
    carrito = []; // Vacía el carrito local
    renderProductos(); // Re-renderiza productos (para actualizar stock)
    renderCarrito(); // Re-renderiza el carrito (para vaciarlo y ocultar contador)
  });
}

